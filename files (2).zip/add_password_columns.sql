-- Add Password Authentication to Staff Table
-- Run this in Supabase SQL Editor

-- 1. Add password columns
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_hash TEXT;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_set_date TIMESTAMP;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN DEFAULT true;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS last_login TIMESTAMP;

-- 2. Set default password for all existing staff
-- Default password: "Welcome123!" 
-- Hash generated with salt

-- You'll need to set passwords individually for each staff member
-- Here's an example for updating one staff member:
/*
UPDATE staff 
SET 
    password_hash = '[generate this with the app or a script]',
    must_change_password = true
WHERE email = 'staff.email@schools.sa.edu.au';
*/

-- 3. Verify the columns were added
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'staff'
AND column_name IN ('password_hash', 'password_set_date', 'must_change_password', 'last_login')
ORDER BY ordinal_position;

-- 4. View staff who need passwords set
SELECT id, email, name, role, password_hash IS NULL as needs_password
FROM staff
WHERE archived = false
ORDER BY role, name;
