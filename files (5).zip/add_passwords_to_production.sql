-- Add password authentication to staff table

-- 1. Add password columns
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_hash TEXT;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_salt TEXT;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_changed_at TIMESTAMP;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS force_password_change BOOLEAN DEFAULT false;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS last_login TIMESTAMP;

-- 2. Set default passwords for existing staff
-- Default password is 'changeme123' - staff must change on first login
-- Password hash generated with bcrypt: $2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QE.4RKyqBR3i

UPDATE staff 
SET 
    password_hash = '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QE.4RKyqBR3i',
    force_password_change = true
WHERE password_hash IS NULL;

-- 3. Verify the columns were added
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'staff'
AND column_name IN ('password_hash', 'password_changed_at', 'force_password_change', 'last_login')
ORDER BY ordinal_position;

-- 4. View staff with their password status
SELECT 
    id, 
    email, 
    name, 
    role,
    CASE WHEN password_hash IS NOT NULL THEN '✓ Has Password' ELSE '✗ No Password' END as password_status,
    force_password_change,
    last_login
FROM staff
WHERE archived = false
ORDER BY role, name;
