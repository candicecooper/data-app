-- Add password fields to staff table
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_hash TEXT;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_set_date TIMESTAMP;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN DEFAULT true;

-- Set a default password hash for existing staff
-- Default password: "Welcome123!" (you should change this)
-- This is bcrypt hash of "Welcome123!"
UPDATE staff 
SET password_hash = '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN.31HYLbkfnRLEzQXCj2',
    must_change_password = true
WHERE password_hash IS NULL;

-- Verify the update
SELECT id, email, name, 
       CASE WHEN password_hash IS NOT NULL THEN 'Password Set' ELSE 'No Password' END as password_status,
       must_change_password
FROM staff
WHERE archived = false;
