import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, date, time, timedelta
import uuid
import random
from collections import Counter
from io import BytesIO

# =========================================
# CONFIG + CONSTANTS
# =========================================

st.set_page_config(
    page_title="CLC Behaviour Support – SANDBOX",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# =========================================
# SLEEK MODERN STYLING
# =========================================

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    * {
        font-family: 'Inter', sans-serif;
    }
    
    .stApp {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    .stButton>button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        color: white !important;
        border: none !important;
        border-radius: 10px !important;
        padding: 0.6rem 1.5rem !important;
        font-weight: 500 !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4) !important;
    }
    
    .stButton>button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6) !important;
    }
    
    button[kind="primary"] {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%) !important;
        box-shadow: 0 4px 15px rgba(79, 172, 254, 0.4) !important;
    }
    
    button[kind="primary"]:hover {
        box-shadow: 0 6px 20px rgba(79, 172, 254, 0.6) !important;
    }
    
    [data-testid="stVerticalBlock"] > div[style*="border"] {
        background: rgba(255, 255, 255, 0.95) !important;
        border-radius: 15px !important;
        padding: 2rem !important;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1) !important;
    }
    
    [data-testid="stMetricValue"] {
        font-size: 2rem !important;
        font-weight: 700 !important;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        -webkit-background-clip: text !important;
        -webkit-text-fill-color: transparent !important;
    }
    
    .stTextInput>div>div>input,
    .stSelectbox>div>div>select,
    .stTextArea>div>div>textarea,
    .stDateInput>div>div>input,
    .stTimeInput>div>div>input,
    .stNumberInput>div>div>input {
        border-radius: 10px !important;
        border: 2px solid #e0e7ff !important;
        transition: all 0.3s ease !important;
    }
    
    .stTextInput>div>div>input:focus,
    .stSelectbox>div>div>select:focus,
    .stTextArea>div>div>textarea:focus {
        border-color: #667eea !important;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1) !important;
    }
    
    h1, h2, h3 {
        color: white !important;
        font-weight: 700 !important;
    }
    
    .streamlit-expanderHeader {
        background: rgba(255, 255, 255, 0.1) !important;
        border-radius: 10px !important;
        backdrop-filter: blur(10px) !important;
        color: white !important;
    }
    
    .stSuccess, .stInfo {
        background: rgba(255, 255, 255, 0.95) !important;
        border-radius: 10px !important;
        border-left: 4px solid #4facfe !important;
    }
    
    .stDownloadButton>button {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%) !important;
        color: white !important;
        border-radius: 10px !important;
        border: none !important;
        box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4) !important;
    }
    
    .stDownloadButton>button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 20px rgba(17, 153, 142, 0.6) !important;
    }
    
    .stTabs [data-baseweb="tab-list"] {
        background: rgba(255, 255, 255, 0.1) !important;
        border-radius: 10px !important;
        padding: 0.5rem !important;
    }
    
    .stTabs [data-baseweb="tab"] {
        color: white !important;
        border-radius: 8px !important;
    }
    
    .stTabs [aria-selected="true"] {
        background: rgba(255, 255, 255, 0.2) !important;
    }
    
    .stSlider {
        padding: 0.5rem 0;
    }
    
    label {
        color: white !important;
        font-weight: 500 !important;
    }
    
    .stMarkdown {
        color: white;
    }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div style='background: rgba(255, 255, 255, 0.95); 
            padding: 1.5rem; 
            border-radius: 15px; 
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border-left: 5px solid #667eea;'>
    <h3 style='color: #667eea; margin: 0; font-size: 1.2rem;'>
        🎭 SANDBOX MODE
    </h3>
    <p style='color: #666; margin: 0.5rem 0 0 0;'>
        This demonstration uses synthetic data only. No real student information is included.
    </p>
</div>
""", unsafe_allow_html=True)

# =========================================
# DATA & CONSTANTS
# =========================================

MOCK_STAFF = [
    {"id": "s1", "name": "Emily Jones", "role": "JP", "email": "emily.jones@example.com"},
    {"id": "s2", "name": "Daniel Lee", "role": "PY", "email": "daniel.lee@example.com"},
    {"id": "s3", "name": "Sarah Chen", "role": "SY", "email": "sarah.chen@example.com"},
    {"id": "s4", "name": "Admin User", "role": "ADM", "email": "admin.user@example.com"},
    {"id": "s5", "name": "Michael Torres", "role": "JP", "email": "michael.torres@example.com"},
    {"id": "s6", "name": "Jessica Williams", "role": "PY", "email": "jessica.williams@example.com"},
]

MOCK_STUDENTS = [
    {"id": "stu_jp1", "name": "Emma T.", "grade": "R", "dob": "2018-05-30", "edid": "ED12348", "program": "JP"},
    {"id": "stu_jp2", "name": "Oliver S.", "grade": "Y1", "dob": "2017-09-12", "edid": "ED12349", "program": "JP"},
    {"id": "stu_jp3", "name": "Sophie M.", "grade": "Y2", "dob": "2016-03-20", "edid": "ED12350", "program": "JP"},
    {"id": "stu_py1", "name": "Liam C.", "grade": "Y3", "dob": "2015-06-15", "edid": "ED12351", "program": "PY"},
    {"id": "stu_py2", "name": "Ava R.", "grade": "Y4", "dob": "2014-11-08", "edid": "ED12352", "program": "PY"},
    {"id": "stu_py3", "name": "Noah B.", "grade": "Y6", "dob": "2012-02-28", "edid": "ED12353", "program": "PY"},
    {"id": "stu_sy1", "name": "Isabella G.", "grade": "Y7", "dob": "2011-04-17", "edid": "ED12354", "program": "SY"},
    {"id": "stu_sy2", "name": "Ethan D.", "grade": "Y9", "dob": "2009-12-03", "edid": "ED12355", "program": "SY"},
    {"id": "stu_sy3", "name": "Mia A.", "grade": "Y11", "dob": "2007-08-20", "edid": "ED12356", "program": "SY"},
]

PROGRAM_NAMES = {"JP": "Junior Primary", "PY": "Primary Years", "SY": "Senior Years"}

SUPPORT_TYPES = ["1:1 Individual Support", "Independent", "Small Group", "Large Group"]

BEHAVIOUR_TYPES = [
    "Verbal Refusal", "Elopement", "Property Destruction", 
    "Aggression (Peer)", "Aggression (Adult)", "Self-Harm", 
    "Verbal Aggression", "Other"
]

ANTECEDENTS = [
    "Requested to transition activity",
    "Given instruction / demand (Academic)",
    "Peer conflict / teasing",
    "Staff attention shifted away",
    "Unstructured free time (Recess/Lunch)",
    "Sensory overload (noise / lights)",
    "Access to preferred item denied",
    "Change in routine or expectation",
    "Difficult task presented",
]

INTERVENTIONS = [
    "Used calm tone and supportive stance (CPI)",
    "Offered a break / time away",
    "Reduced task demand / chunked task",
    "Provided choices",
    "Removed audience / peers",
    "Used visual supports",
    "Co-regulated with breathing / grounding",
    "Prompted use of coping skill",
    "Redirection to preferred activity",
]

LOCATIONS = [
    "JP Classroom", "JP Spill Out", "PY Classroom", "PY Spill Out",
    "SY Classroom", "SY Spill Out", "Student Kitchen", "Admin",
    "Gate", "Library", "Playground", "Yard", "Toilets", "Excursion", "Swimming"
]

VALID_PAGES = [
    "login", "landing", "program_students", "incident_log",
    "critical_incident", "student_analysis", "program_overview"
]

# =========================================
# WORD DOCUMENT GENERATION
# =========================================

def generate_behaviour_analysis_plan_docx(student, full_df, top_ant, top_beh, top_loc, top_session, risk_score, risk_level):
    """Generate a Word document for Behaviour Analysis Plan"""
    try:
        from docx import Document
        from docx.shared import Inches, Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        
        doc = Document()
        
        # Title
        title = doc.add_heading('Behaviour Analysis Plan', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Student Info
        doc.add_heading('Student Information', 1)
        student_table = doc.add_table(rows=4, cols=2)
        student_table.style = 'Light Grid Accent 1'
        
        student_table.rows[0].cells[0].text = 'Student Name:'
        student_table.rows[0].cells[1].text = student['name']
        student_table.rows[1].cells[0].text = 'Program:'
        student_table.rows[1].cells[1].text = student['program']
        student_table.rows[2].cells[0].text = 'Grade:'
        student_table.rows[2].cells[1].text = student['grade']
        student_table.rows[3].cells[0].text = 'Report Date:'
        student_table.rows[3].cells[1].text = datetime.now().strftime('%d/%m/%Y')
        
        doc.add_paragraph()
        
        # Executive Summary
        doc.add_heading('Executive Summary', 1)
        summary_para = doc.add_paragraph()
        summary_para.add_run(f"Total Incidents: ").bold = True
        summary_para.add_run(f"{len(full_df)}\n")
        summary_para.add_run(f"Critical Incidents: ").bold = True
        summary_para.add_run(f"{len(full_df[full_df['incident_type'] == 'Critical'])}\n")
        summary_para.add_run(f"Average Severity: ").bold = True
        summary_para.add_run(f"{full_df['severity'].mean():.2f}\n")
        summary_para.add_run(f"Risk Level: ").bold = True
        summary_para.add_run(f"{risk_level} ({risk_score}/100)")
        
        doc.add_paragraph()
        
        # Data Findings
        doc.add_heading('Summary of Data Findings', 1)
        findings = doc.add_paragraph()
        findings.add_run('Primary Concern: ').bold = True
        findings.add_run(f"{top_beh} is the most frequently recorded behaviour of concern.\n\n")
        findings.add_run('Key Triggers: ').bold = True
        findings.add_run(f"The most common antecedent is '{top_ant}', indicating this context regularly precedes dysregulation.\n\n")
        findings.add_run('Hotspot Locations: ').bold = True
        findings.add_run(f"Incidents most often occur in {top_loc}, particularly during the {top_session} session.")
        
        doc.add_paragraph()
        
        # Clinical Interpretation
        doc.add_heading('Clinical Interpretation (Trauma-Informed)', 1)
        clinical = doc.add_paragraph()
        clinical.add_run(
            f"Patterns suggest that {student['name']} is most vulnerable when '{top_ant}' occurs, "
            f"often in the {top_loc} during {top_session}. These moments likely narrow the student's "
            "window of tolerance, increasing the risk of fight/flight responses.\n\n"
        )
        clinical.add_run(
            "Through a trauma-informed lens, this behaviour is understood as a safety strategy rather than "
            "wilful defiance. CPI emphasises staying in the Supportive phase as early as possible — calm body "
            "language, non-threatening stance and minimal verbal load.\n\n"
        )
        clinical.add_run(
            "The Berry Street Education Model (Body, Relationship, Stamina, Engagement) points towards "
            "strengthening Body (regulation routines, predictable transitions) and Relationship "
            "(connection before correction)."
        )
        
        doc.add_paragraph()
        
        # Recommendations
        doc.add_heading('Recommendations & Next Steps', 1)
        
        doc.add_heading('1. Proactive Regulation Around Key Triggers', 2)
        rec1 = doc.add_paragraph(style='List Bullet')
        rec1.add_run(f"Provide a brief check-in and clear visual cue before '{top_ant}'")
        rec2 = doc.add_paragraph(style='List Bullet')
        rec2.add_run(f"Offer a regulated start (breathing, movement, sensory tool) before the high-risk {top_session} session")
        
        doc.add_heading('2. Co-regulation & Staff Responses (CPI Aligned)', 2)
        rec3 = doc.add_paragraph(style='List Bullet')
        rec3.add_run("Use CPI Supportive stance, low slow voice and minimal language when early signs of escalation appear")
        rec4 = doc.add_paragraph(style='List Bullet')
        rec4.add_run("Reduce audience by moving peers where possible and maintain connection with one key adult")
        
        doc.add_heading('3. Teaching Replacement Skills (Australian Curriculum)', 2)
        rec5 = doc.add_paragraph(style='List Bullet')
        rec5.add_run("Link goals to Personal and Social Capability (self-management & social management)")
        rec6 = doc.add_paragraph(style='List Bullet')
        rec6.add_run("Explicitly teach and rehearse a help-seeking routine the student can use in place of the behaviour")
        
        doc.add_heading('4. SMART Goal Example', 2)
        goal = doc.add_paragraph(style='List Bullet')
        goal.add_run(
            f"Over the next 5 weeks, during identified trigger times, the student will use "
            f"an agreed help-seeking strategy instead of the behaviour of concern in "
            f"4 out of 5 opportunities, with co-regulation support from staff."
        )
        
        doc.add_paragraph()
        
        # Footer
        footer_para = doc.add_paragraph()
        footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_run = footer_para.add_run('\n\nGenerated by CLC Behaviour Support System\n')
        footer_run.font.size = Pt(9)
        footer_run.font.color.rgb = RGBColor(128, 128, 128)
        footer_para.add_run(datetime.now().strftime('%d %B %Y at %I:%M %p'))
        
        # Save to BytesIO
        file_stream = BytesIO()
        doc.save(file_stream)
        file_stream.seek(0)
        return file_stream
        
    except ImportError:
        st.error("⚠️ python-docx library not installed. Install with: pip install python-docx")
        return None
    except Exception as e:
        st.error(f"Error generating Word document: {e}")
        return None

# =========================================
# HELPER FUNCTIONS
# =========================================

def init_state():
    ss = st.session_state
    if "logged_in" not in ss:
        ss.logged_in = False
    if "current_user" not in ss:
        ss.current_user = None
    if "current_page" not in ss:
        ss.current_page = "login"
    if "students" not in ss:
        ss.students = MOCK_STUDENTS
    if "staff" not in ss:
        ss.staff = MOCK_STAFF
    if "incidents" not in ss:
        ss.incidents = generate_mock_incidents(70)
    if "critical_incidents" not in ss:
        ss.critical_incidents = []
    if "selected_program" not in ss:
        ss.selected_program = "JP"
    if "selected_student_id" not in ss:
        ss.selected_student_id = None
    if "current_incident_id" not in ss:
        ss.current_incident_id = None
    if "abch_rows" not in ss:
        ss.abch_rows = []

def login_user(email: str) -> bool:
    email = (email or "").strip().lower()
    if not email:
        return False

    for staff in st.session_state.staff:
        if staff.get("email", "").lower() == email:
            st.session_state.logged_in = True
            st.session_state.current_user = staff
            st.session_state.current_page = "landing"
            return True

    demo = {"id": "demo_staff", "name": "Demo User", "role": "JP", "email": email}
    st.session_state.logged_in = True
    st.session_state.current_user = demo
    st.session_state.current_page = "landing"
    return True

def go_to(page: str, **kwargs):
    if page not in VALID_PAGES:
        st.error(f"Unknown page: {page}")
        return
    st.session_state.current_page = page
    for k, v in kwargs.items():
        setattr(st.session_state, k, v)
    st.rerun()

def get_student(student_id: str):
    if not student_id:
        return None
    return next((s for s in st.session_state.students if s["id"] == student_id), None)

def get_active_staff():
    return st.session_state.staff

def get_session_from_time(t: time) -> str:
    h = t.hour
    if h < 11:
        return "Morning"
    elif h < 13:
        return "Middle"
    else:
        return "Afternoon"

def calculate_age(dob_str: str):
    try:
        d = datetime.strptime(dob_str, "%Y-%m-%d").date()
        today = date.today()
        years = today.year - d.year - ((today.month, today.day) < (d.month, d.day))
        return years
    except Exception:
        return None

def generate_mock_incidents(n: int = 70):
    incidents = []
    student_weights = {
        "stu_jp1": 8, "stu_jp2": 5, "stu_jp3": 3,
        "stu_py1": 10, "stu_py2": 7, "stu_py3": 4,
        "stu_sy1": 12, "stu_sy2": 9, "stu_sy3": 6,
    }
    
    student_pool = []
    for stu in MOCK_STUDENTS:
        weight = student_weights.get(stu["id"], 5)
        student_pool.extend([stu] * weight)
    
    for _ in range(n):
        stu = random.choice(student_pool)
        beh = random.choice(BEHAVIOUR_TYPES)
        ant = random.choice(ANTECEDENTS)
        loc = random.choice(LOCATIONS)
        support = random.choice(SUPPORT_TYPES)
        interv = random.choice(INTERVENTIONS)
        sev = random.choices([1, 2, 3, 4, 5], weights=[20, 35, 25, 15, 5])[0]
        dt = datetime.now() - timedelta(days=random.randint(0, 90))
        t_hour = random.choices([9, 10, 11, 12, 13, 14, 15], weights=[10, 15, 12, 8, 12, 18, 10])[0]
        dt = dt.replace(hour=t_hour, minute=random.randint(0, 59), second=0)

        incidents.append({
            "id": str(uuid.uuid4()),
            "student_id": stu["id"],
            "student_name": stu["name"],
            "date": dt.date().isoformat(),
            "time": dt.time().strftime("%H:%M:%S"),
            "day": dt.strftime("%A"),
            "session": get_session_from_time(dt.time()),
            "location": loc,
            "behaviour_type": beh,
            "antecedent": ant,
            "support_type": support,
            "intervention": interv,
            "severity": sev,
            "reported_by": random.choice(MOCK_STAFF)["name"],
            "additional_staff": [],
            "description": "Auto-generated mock incident.",
            "hypothesis": generate_simple_function(ant, beh),
            "is_critical": sev >= 4,
            "duration_minutes": random.randint(2, 25),
        })
    return incidents

def generate_simple_function(antecedent: str, behaviour: str) -> str:
    ant = (antecedent or "").lower()
    if any(k in ant for k in ["instruction", "demand", "work", "task", "academic"]):
        return "To avoid request / activity"
    elif "transition" in ant:
        return "To avoid transition / activity"
    elif any(k in ant for k in ["denied", "access", "item", "object", "preferred"]):
        return "To get tangible"
    elif any(k in ant for k in ["sensory", "noise", "lights", "overload"]):
        return "To avoid sensory"
    elif any(k in ant for k in ["peer", "attention", "staff"]):
        return "To get attention"
    else:
        return "To get attention"

