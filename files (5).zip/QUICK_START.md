# ⚡ QUICK START GUIDE

## 🎯 TWO VERSIONS READY TO GO!

---

## 🏭 PRODUCTION VERSION (Real Data + Passwords)

### 3 Steps to Enable Passwords:

1. **Run this SQL in Supabase:**
```sql
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_hash TEXT;
UPDATE staff 
SET password_hash = '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TupxkLobaczS9l6zAm7mQ6K6meLW'
WHERE password_hash IS NULL;
```

2. **Deploy the app:**
   - Download: `app_PRODUCTION_WITH_PASSWORDS.py`
   - Rename to: `app.py`
   - Restart Streamlit

3. **Login:**
   - Email: Any staff email (e.g., candice.cooper330@schools.sa.edu.au)
   - Password: `password123`

✅ **DONE!** Your production app now has password protection!

---

## 🎭 DEMO VERSION (Synthetic Data - No Database)

### 1 Step to Run:

```bash
streamlit run app_DEMO_VERSION.py
```

✅ **DONE!** Demo with 9 students, 6 staff, 60+ incidents ready!

---

## 📥 FILES TO DOWNLOAD

1. **app_PRODUCTION_WITH_PASSWORDS.py** ← Your main app
2. **app_DEMO_VERSION.py** ← Shareable demo
3. **add_password_authentication.sql** ← SQL script
4. **COMPLETE_SETUP_GUIDE.md** ← Full documentation

---

## 🔑 DEFAULT LOGIN CREDENTIALS

**Email:** Any staff email in your database
**Password:** `password123`

(All staff should change this password!)

---

## 🎊 THAT'S IT!

You now have:
- ✅ Working production app with passwords
- ✅ Shareable demo version
- ✅ Can add staff and students
- ✅ Full analytics and reporting

Enjoy! 🚀
