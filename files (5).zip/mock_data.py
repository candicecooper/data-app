"""
Mock data for demo version of Behaviour Support App
This file contains realistic synthetic data for demonstration purposes
"""

from datetime import datetime, timedelta, time
import random

# Generate dates for the last 90 days
def get_random_date_last_90_days():
    days_ago = random.randint(0, 90)
    return (datetime.now() - timedelta(days=days_ago)).strftime('%Y-%m-%d')

def get_random_time():
    """Generate random time during school hours (9am-3pm)"""
    hour = random.randint(9, 14)
    minute = random.choice([0, 15, 30, 45])
    return f"{hour:02d}:{minute:02d}:00"

# Mock Students - 9 total (3 per program)
MOCK_STUDENTS = [
    # JP Program
    {
        'id': 'student_JP001',
        'student_id': 'JP001',
        'first_name': 'Emma',
        'last_name': 'Thompson',
        'name': 'Emma Thompson',
        'grade': 'R',
        'program': 'JP',
        'dob': '2018-03-15',
        'edid': 'JP001',
        'profile_status': 'Complete',
        'archived': False
    },
    {
        'id': 'student_JP002',
        'student_id': 'JP002',
        'first_name': 'Oliver',
        'last_name': 'Martinez',
        'name': 'Oliver Martinez',
        'grade': 'Y1',
        'program': 'JP',
        'dob': '2017-07-22',
        'edid': 'JP002',
        'profile_status': 'Complete',
        'archived': False
    },
    {
        'id': 'student_JP003',
        'student_id': 'JP003',
        'first_name': 'Sophia',
        'last_name': 'Wilson',
        'name': 'Sophia Wilson',
        'grade': 'Y2',
        'program': 'JP',
        'dob': '2016-11-08',
        'edid': 'JP003',
        'profile_status': 'Complete',
        'archived': False
    },
    # PY Program
    {
        'id': 'student_PY001',
        'student_id': 'PY001',
        'first_name': 'Liam',
        'last_name': 'Chen',
        'name': 'Liam Chen',
        'grade': 'Y3',
        'program': 'PY',
        'dob': '2015-05-30',
        'edid': 'PY001',
        'profile_status': 'Complete',
        'archived': False
    },
    {
        'id': 'student_PY002',
        'student_id': 'PY002',
        'first_name': 'Ava',
        'last_name': 'Rodriguez',
        'name': 'Ava Rodriguez',
        'grade': 'Y4',
        'program': 'PY',
        'dob': '2014-09-12',
        'edid': 'PY002',
        'profile_status': 'Complete',
        'archived': False
    },
    {
        'id': 'student_PY003',
        'student_id': 'PY003',
        'first_name': 'Noah',
        'last_name': 'Brown',
        'name': 'Noah Brown',
        'grade': 'Y6',
        'program': 'PY',
        'dob': '2013-01-25',
        'edid': 'PY003',
        'profile_status': 'Complete',
        'archived': False
    },
    # SY Program
    {
        'id': 'student_SY001',
        'student_id': 'SY001',
        'first_name': 'Isabella',
        'last_name': 'Garcia',
        'name': 'Isabella Garcia',
        'grade': 'Y7',
        'program': 'SY',
        'dob': '2012-04-17',
        'edid': 'SY001',
        'profile_status': 'Complete',
        'archived': False
    },
    {
        'id': 'student_SY002',
        'student_id': 'SY002',
        'first_name': 'Ethan',
        'last_name': 'Davis',
        'name': 'Ethan Davis',
        'grade': 'Y9',
        'program': 'SY',
        'dob': '2010-12-03',
        'edid': 'SY002',
        'profile_status': 'Complete',
        'archived': False
    },
    {
        'id': 'student_SY003',
        'student_id': 'SY003',
        'first_name': 'Mia',
        'last_name': 'Anderson',
        'name': 'Mia Anderson',
        'grade': 'Y11',
        'program': 'SY',
        'dob': '2008-08-19',
        'edid': 'SY003',
        'profile_status': 'Complete',
        'archived': False
    }
]

# Mock Staff - 6 total
MOCK_STAFF = [
    {
        'id': 'staff_demo1',
        'first_name': 'Sarah',
        'last_name': 'Johnson',
        'name': 'Sarah Johnson',
        'email': 'sarah.johnson@demo.edu.au',
        'password_hash': '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QE.4RKyqBR3i',  # password: demo123
        'role': 'JP',
        'active': True,
        'archived': False
    },
    {
        'id': 'staff_demo2',
        'first_name': 'Michael',
        'last_name': 'Lee',
        'name': 'Michael Lee',
        'email': 'michael.lee@demo.edu.au',
        'password_hash': '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QE.4RKyqBR3i',
        'role': 'JP',
        'active': True,
        'archived': False
    },
    {
        'id': 'staff_demo3',
        'first_name': 'Jessica',
        'last_name': 'Williams',
        'name': 'Jessica Williams',
        'email': 'jessica.williams@demo.edu.au',
        'password_hash': '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QE.4RKyqBR3i',
        'role': 'PY',
        'active': True,
        'archived': False
    },
    {
        'id': 'staff_demo4',
        'first_name': 'David',
        'last_name': 'Martinez',
        'name': 'David Martinez',
        'email': 'david.martinez@demo.edu.au',
        'password_hash': '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QE.4RKyqBR3i',
        'role': 'PY',
        'active': True,
        'archived': False
    },
    {
        'id': 'staff_demo5',
        'first_name': 'Emily',
        'last_name': 'Brown',
        'name': 'Emily Brown',
        'email': 'emily.brown@demo.edu.au',
        'password_hash': '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QE.4RKyqBR3i',
        'role': 'SY',
        'active': True,
        'archived': False
    },
    {
        'id': 'staff_demo6',
        'first_name': 'James',
        'last_name': 'Wilson',
        'name': 'James Wilson',
        'email': 'james.wilson@demo.edu.au',
        'password_hash': '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5QE.4RKyqBR3i',
        'role': 'SY',
        'active': True,
        'archived': False
    }
]

# Behavior types and settings for realistic incident generation
BEHAVIOURS_FBA = ['Verbal Refusal', 'Elopement', 'Property Destruction', 'Aggression (Peer)', 'Self-Harm']
BEHAVIOUR_LEVELS = ['1 - Low Intensity', '2 - Moderate', '3 - High Risk']
ANTECEDENTS = [
    "Requested to transition activity",
    "Given instruction/demand (Academic)",
    "Peer conflict/Teasing",
    "Unstructured free time (Recess/Lunch)",
    "Access to preferred item/activity denied"
]
INTERVENTIONS = [
    "Prompted use of coping skill (e.g., breathing)",
    "Redirection to a preferred activity",
    "Offered a break/Choice of task",
    "Staff de-escalation script/Verbal coaching",
    "Called for staff support/Backup"
]
LOCATIONS = ["JP Classroom", "PY Classroom", "SY Classroom", "Playground", "Library", "Yard"]

# Generate mock incidents
def generate_mock_incidents():
    """Generate 60 realistic incidents across all students"""
    incidents = []
    incident_id = 1
    
    # Each student gets different number of incidents based on severity
    student_incident_counts = {
        'student_JP001': 8,   # Emma - moderate
        'student_JP002': 12,  # Oliver - higher
        'student_JP003': 5,   # Sophia - low
        'student_PY001': 10,  # Liam - moderate-high
        'student_PY002': 6,   # Ava - low-moderate
        'student_PY003': 9,   # Noah - moderate
        'student_SY001': 7,   # Isabella - moderate
        'student_SY002': 11,  # Ethan - high
        'student_SY003': 4    # Mia - low
    }
    
    for student_id, count in student_incident_counts.items():
        student = next(s for s in MOCK_STUDENTS if s['id'] == student_id)
        staff_for_program = [s for s in MOCK_STAFF if s['role'] == student['program']]
        
        for i in range(count):
            incident_date = get_random_date_last_90_days()
            incident_time = get_random_time()
            
            # Parse date to get day of week
            date_obj = datetime.strptime(incident_date, '%Y-%m-%d')
            day_of_week = date_obj.strftime('%A')
            
            incident = {
                'id': f'inc_{incident_id:03d}',
                'student_id': student_id,
                'student_name': student['name'],
                'reported_by': random.choice(staff_for_program)['name'],
                'incident_date': incident_date,
                'date': incident_date,
                'incident_time': incident_time,
                'time': incident_time,
                'day_of_week': day_of_week,
                'day': day_of_week,
                'location': random.choice([loc for loc in LOCATIONS if student['program'] in loc] or LOCATIONS),
                'behaviour_type': random.choice(BEHAVIOURS_FBA),
                'severity_level': random.choice(BEHAVIOUR_LEVELS),
                'antecedent': random.choice(ANTECEDENTS),
                'intervention': random.choice(INTERVENTIONS),
                'outcome': random.choice(['De-escalated', 'Resolved', 'Escalated - Admin Called', 'Student calmed down']),
                'duration_minutes': random.randint(5, 45),
                'notes': f'Student displayed {random.choice(BEHAVIOURS_FBA).lower()}. {random.choice(INTERVENTIONS)} was used.',
                'support_type': random.choice(['1:1 (Individual Support)', 'Small Group (3-5 students)']),
                'created_at': incident_date + ' ' + incident_time
            }
            incidents.append(incident)
            incident_id += 1
    
    return incidents

MOCK_INCIDENTS = generate_mock_incidents()

# System settings
MOCK_SYSTEM_SETTINGS = {
    'school_name': 'Demo Behaviour Support School',
    'school_year': '2024-2025',
    'enable_notifications': 'true'
}
