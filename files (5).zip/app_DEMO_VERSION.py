import streamlit as st
import pandas as pd
from datetime import datetime, time, timedelta
import random
import plotly.express as px
from typing import List, Dict

# =============================================================================
# DEMO VERSION - Behaviour Support & Data Analysis Tool
# =============================================================================
# This is a demonstration version with synthetic data
# No database connection required - all data is mock/fake
# =============================================================================

st.set_page_config(
    page_title="Behaviour Support Demo",
    layout="wide",
    initial_sidebar_state="collapsed",
    page_icon="📊"
)

# =============================================================================
# MOCK DATA
# =============================================================================

MOCK_STAFF = [
    {'id': 'staff_1', 'name': 'Sarah Johnson', 'email': 'sarah.j@demo.com', 'role': 'JP'},
    {'id': 'staff_2', 'name': 'Michael Lee', 'email': 'michael.l@demo.com', 'role': 'JP'},
    {'id': 'staff_3', 'name': 'Jessica Williams', 'email': 'jessica.w@demo.com', 'role': 'PY'},
    {'id': 'staff_4', 'name': 'David Martinez', 'email': 'david.m@demo.com', 'role': 'PY'},
    {'id': 'staff_5', 'name': 'Emily Brown', 'email': 'emily.b@demo.com', 'role': 'SY'},
    {'id': 'staff_6', 'name': 'James Wilson', 'email': 'james.w@demo.com', 'role': 'SY'},
]

MOCK_STUDENTS = [
    # JP Program
    {'id': 'stu_jp_1', 'name': 'Emma Thompson', 'grade': 'R', 'dob': '2018-03-15', 'edid': 'JP001', 'program': 'JP'},
    {'id': 'stu_jp_2', 'name': 'Oliver Martinez', 'grade': 'Y1', 'dob': '2017-07-22', 'edid': 'JP002', 'program': 'JP'},
    {'id': 'stu_jp_3', 'name': 'Sophia Wilson', 'grade': 'Y2', 'dob': '2016-11-08', 'edid': 'JP003', 'program': 'JP'},
    # PY Program
    {'id': 'stu_py_1', 'name': 'Liam Chen', 'grade': 'Y3', 'dob': '2015-05-30', 'edid': 'PY001', 'program': 'PY'},
    {'id': 'stu_py_2', 'name': 'Ava Rodriguez', 'grade': 'Y4', 'dob': '2014-09-12', 'edid': 'PY002', 'program': 'PY'},
    {'id': 'stu_py_3', 'name': 'Noah Brown', 'grade': 'Y6', 'dob': '2012-01-25', 'edid': 'PY003', 'program': 'PY'},
    # SY Program
    {'id': 'stu_sy_1', 'name': 'Isabella Garcia', 'grade': 'Y7', 'dob': '2011-04-17', 'edid': 'SY001', 'program': 'SY'},
    {'id': 'stu_sy_2', 'name': 'Ethan Davis', 'grade': 'Y9', 'dob': '2009-12-03', 'edid': 'SY002', 'program': 'SY'},
    {'id': 'stu_sy_3', 'name': 'Mia Anderson', 'grade': 'Y11', 'dob': '2007-08-19', 'edid': 'SY003', 'program': 'SY'},
]

def generate_mock_incidents():
    incidents = []
    behaviours = ['Verbal Refusal', 'Elopement', 'Property Destruction', 'Aggression (Peer)', 'Physical Aggression']
    severities = ['1 - Low Intensity', '2 - Moderate', '3 - High Risk']
    locations = ['JP Classroom', 'PY Classroom', 'SY Classroom', 'Playground', 'Yard', 'Library']
    interventions = ['Prompted coping skill', 'Proximity control', 'Redirection', 'Offered break', 'Staff support']
    
    start_date = datetime.now() - timedelta(days=90)
    incident_id = 1
    
    for student in MOCK_STUDENTS:
        num_incidents = random.randint(5, 8)
        for i in range(num_incidents):
            inc_date = start_date + timedelta(days=random.randint(0, 90))
            inc_time = time(hour=random.randint(9, 14), minute=random.choice([0, 15, 30, 45]))
            
            incidents.append({
                'id': f'inc_{incident_id}',
                'student_id': student['id'],
                'student_name': student['name'],
                'date': inc_date.strftime('%Y-%m-%d'),
                'time': inc_time.strftime('%H:%M'),
                'day': inc_date.strftime('%A'),
                'behaviour_type': random.choice(behaviours),
                'severity_level': random.choice(severities),
                'location': random.choice(locations),
                'reported_by': random.choice(MOCK_STAFF)['name'],
                'intervention': random.choice(interventions),
                'outcome': random.choice(['Resolved', 'Extended support', 'Escalated', 'De-escalated']),
                'duration_minutes': random.randint(5, 45),
            })
            incident_id += 1
    
    return incidents

MOCK_INCIDENTS = generate_mock_incidents()

# =============================================================================
# SESSION STATE
# =============================================================================

if 'current_page' not in st.session_state:
    st.session_state.current_page = 'landing'

def navigate_to(page: str):
    st.session_state.current_page = page
    st.rerun()

# =============================================================================
# PAGES
# =============================================================================

def render_demo_notice():
    st.info("🎭 **DEMO VERSION** - Synthetic data only. No real student information.")

def render_landing():
    render_demo_notice()
    st.title("📊 Behaviour Support & Data Analysis - DEMO")
    st.markdown("### Select a Program")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("#### 🎨 Junior Primary")
        if st.button("View JP", use_container_width=True):
            navigate_to('jp')
    with col2:
        st.markdown("#### 📐 Primary Years")
        if st.button("View PY", use_container_width=True):
            navigate_to('py')
    with col3:
        st.markdown("#### 🔬 Senior Years")
        if st.button("View SY", use_container_width=True):
            navigate_to('sy')
    
    st.markdown("---")
    if st.button("📈 View Analytics", use_container_width=True, type="primary"):
        navigate_to('analytics')

def render_program(program: str):
    render_demo_notice()
    program_names = {'jp': 'Junior Primary', 'py': 'Primary Years', 'sy': 'Senior Years'}
    st.title(f"🎓 {program_names[program]} Students")
    
    if st.button("← Back"):
        navigate_to('landing')
    
    students = [s for s in MOCK_STUDENTS if s['program'] == program.upper()]
    
    for student in students:
        with st.expander(f"**{student['name']}** - Grade {student['grade']}"):
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**EDID:** {student['edid']}")
                st.write(f"**DOB:** {student['dob']}")
            with col2:
                incidents = [i for i in MOCK_INCIDENTS if i['student_id'] == student['id']]
                st.metric("Total Incidents", len(incidents))
            
            if st.button(f"View Analysis", key=f"view_{student['id']}"):
                st.session_state.selected_student = student['id']
                navigate_to('analysis')

def render_analytics():
    render_demo_notice()
    st.title("📈 Analytics Dashboard")
    
    if st.button("← Back"):
        navigate_to('landing')
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Incidents", len(MOCK_INCIDENTS))
    with col2:
        st.metric("Students", len(MOCK_STUDENTS))
    with col3:
        avg = len(MOCK_INCIDENTS) / len(MOCK_STUDENTS)
        st.metric("Avg per Student", f"{avg:.1f}")
    with col4:
        high_risk = len([i for i in MOCK_INCIDENTS if '3' in i['severity_level']])
        st.metric("High Risk", high_risk)
    
    st.markdown("---")
    st.markdown("### Incidents by Behaviour Type")
    
    behaviour_counts = {}
    for inc in MOCK_INCIDENTS:
        bt = inc['behaviour_type']
        behaviour_counts[bt] = behaviour_counts.get(bt, 0) + 1
    
    fig = px.bar(x=list(behaviour_counts.keys()), y=list(behaviour_counts.values()),
                 labels={'x': 'Behaviour', 'y': 'Count'})
    st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("### Incidents by Program")
    program_counts = {}
    for inc in MOCK_INCIDENTS:
        stu = next(s for s in MOCK_STUDENTS if s['id'] == inc['student_id'])
        prog = stu['program']
        program_counts[prog] = program_counts.get(prog, 0) + 1
    
    fig2 = px.pie(values=list(program_counts.values()), names=list(program_counts.keys()))
    st.plotly_chart(fig2, use_container_width=True)

def render_analysis():
    render_demo_notice()
    student_id = st.session_state.get('selected_student')
    if not student_id:
        st.error("No student selected")
        if st.button("← Back"):
            navigate_to('landing')
        return
    
    student = next(s for s in MOCK_STUDENTS if s['id'] == student_id)
    st.title(f"📊 {student['name']} - Analysis")
    
    if st.button("← Back"):
        navigate_to(student['program'].lower())
    
    incidents = [i for i in MOCK_INCIDENTS if i['student_id'] == student_id]
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Grade", student['grade'])
    with col2:
        st.metric("Total Incidents", len(incidents))
    with col3:
        if incidents:
            avg_sev = sum([1 if '1' in i['severity_level'] else 2 if '2' in i['severity_level'] else 3 for i in incidents]) / len(incidents)
            st.metric("Avg Severity", f"{avg_sev:.1f}")
    
    st.markdown("---")
    st.markdown("### Recent Incidents")
    
    recent = sorted(incidents, key=lambda x: x['date'], reverse=True)[:10]
    for inc in recent:
        with st.expander(f"{inc['date']} - {inc['behaviour_type']}"):
            st.write(f"**Time:** {inc['time']}")
            st.write(f"**Location:** {inc['location']}")
            st.write(f"**Severity:** {inc['severity_level']}")
            st.write(f"**Reported by:** {inc['reported_by']}")

# =============================================================================
# MAIN
# =============================================================================

def main():
    page = st.session_state.current_page
    
    if page == 'landing':
        render_landing()
    elif page in ['jp', 'py', 'sy']:
        render_program(page)
    elif page == 'analytics':
        render_analytics()
    elif page == 'analysis':
        render_analysis()

if __name__ == '__main__':
    main()
