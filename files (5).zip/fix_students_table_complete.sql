-- Add ALL missing columns to students table

-- Add program column
ALTER TABLE students ADD COLUMN IF NOT EXISTS program TEXT;

-- Add profile_status column
ALTER TABLE students ADD COLUMN IF NOT EXISTS profile_status TEXT DEFAULT 'Draft';

-- Add archived column
ALTER TABLE students ADD COLUMN IF NOT EXISTS archived BOOLEAN DEFAULT false;

-- Add dob column if missing
ALTER TABLE students ADD COLUMN IF NOT EXISTS dob DATE;

-- Add edid column if missing
ALTER TABLE students ADD COLUMN IF NOT EXISTS edid TEXT;

-- Add created_date for tracking
ALTER TABLE students ADD COLUMN IF NOT EXISTS created_date TIMESTAMP DEFAULT NOW();

-- Verify all columns exist
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'students'
ORDER BY ordinal_position;

-- Test insert to see if it works
-- (You can delete this test record after)
INSERT INTO students (first_name, last_name, name, dob, program, grade, edid, profile_status, archived)
VALUES ('Test', 'Student', 'Test Student', '2015-01-01', 'JP', 'R', 'TEST001', 'Draft', false)
ON CONFLICT DO NOTHING;

-- Show the test record
SELECT * FROM students WHERE edid = 'TEST001';
