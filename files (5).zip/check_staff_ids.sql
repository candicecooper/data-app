-- Check current staff records and their IDs
SELECT id, first_name, last_name, name, email, role, active, archived
FROM staff
ORDER BY created_at;

-- If some have NULL ids, we need to see the table structure
SELECT column_name, data_type, column_default, is_nullable
FROM information_schema.columns
WHERE table_name = 'staff'
AND column_name = 'id';

-- Check if there's an auto-increment sequence for the id
SELECT 
    c.column_name,
    c.column_default,
    c.is_nullable,
    c.data_type
FROM information_schema.columns c
WHERE c.table_name = 'staff'
ORDER BY c.ordinal_position;
