-- Add password authentication to staff table

-- Add password field (will store hashed passwords)
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_hash TEXT;

-- Add metadata fields for password management
ALTER TABLE staff ADD COLUMN IF NOT EXISTS password_set_at TIMESTAMP;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN DEFAULT false;
ALTER TABLE staff ADD COLUMN IF NOT EXISTS last_login TIMESTAMP;

-- Set default password for existing staff
-- Default password will be: "Welcome2024!" (hashed)
-- They should change this on first login

-- For testing, let's set a simple default password hash
-- This is the bcrypt hash for "password123"
-- In production, each staff should set their own password

UPDATE staff 
SET password_hash = '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TupxkLobaczS9l6zAm7mQ6K6meLW',
    must_change_password = true
WHERE password_hash IS NULL;

-- Verify the update
SELECT id, email, name, 
       CASE WHEN password_hash IS NOT NULL THEN 'SET' ELSE 'NOT SET' END as password_status,
       must_change_password
FROM staff
WHERE archived = false;
